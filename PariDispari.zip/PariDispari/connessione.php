<?php
try{
    $db = new PDO(
        'mysql:host=localhost;dbname=pari_dispari;charset=utf8mb4',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
	echo $e->getMessage();
	die;
}
