<?php

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();

    if(isset($_SESSION)) {
        $_SESSION= [];
    }
    $_SESSION['nomeGiocatore'] = $_POST['nome'];
    $_SESSION['sceltaTipo'] = $_POST['tipo'];
    header('location:tentativo_giocatore.php');

    
} else {
    echo '<form method="post">
            Inserisci nome giocatore: <input type="text" name="nome" id="nome"><br>
            <br>
            <input type="radio" id="" name="tipo" value="pari">
            <label>Scegli PARI!</label><br>
            <input type="radio" id="" name="tipo" value="dispari">
            <label>Scegli DISPARI!</label><br>
            <br>
            <input type="submit" value="INIZIAMO!">
        </form>
    ';
    
    echo '<h4 style="color: red;">" La scelta fatta vale per tutta la sfida, 
    La partita sarà al meglio dei tre turni, chi ne vince due
    si aggiudicherà la partita"</h4>';
}

?>