<?php

session_start();

$max_tentativi = 3;

if($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!isset($_SESSION['history'])){
        $_SESSION['history']=[];
    }
    $sceltaTipoUtente =  $_SESSION['sceltaTipo'];

    if ($sceltaTipoUtente == 'pari') {
        $sceltaTipoComputer = 'dispari';
    }else{
        $sceltaTipoComputer = 'pari';
    }

    //echo 'Io ho scelto: '.$sceltaTipoUtente.'<br>';
    //echo 'Il computer ha scelto: '.$sceltaTipoComputer.'<br>';

    $scelta = $_GET['scelta'];
    //echo 'Il mio numero è: '.$scelta.'<br>';

    $arrayNumeri = [0,1,2,3,4,5];
    $sceltaPCnumero = array_rand($arrayNumeri, 1);
    echo 'Il computer ha tirato: '. $sceltaPCnumero.'<br>';

    $somma = $scelta + $sceltaPCnumero;
    //echo 'Somma: '.$somma.'<br>';

    $vincitore;
    $punteggioUtente = 0;
    $punteggioPc = 0;

    if ($somma %2 == 0 && $sceltaTipoUtente == 'pari') {
        echo 'Hai vinto!';
        $vincitore = 'Utente';
        $punteggioUtente++;
    }else if ($somma %2 == 0 && $sceltaTipoUtente == 'dispari') {
        echo 'Ha vinto il computer!';
        $vincitore = 'Computer';
        $punteggioPc++;
    }elseif ($somma %2 != 0 && $sceltaTipoComputer == 'dispari') {
        echo 'Ha vinto il computer!';
        $vincitore = 'Computer';
        $punteggioPc++;
    }else{
        echo 'Hai vinto!';
        $vincitore = 'Utente';
        $punteggioUtente++;
    }

    

    $punteggioVincitore;
    if ($punteggioUtente > $punteggioPc) {
        $punteggioVincitore = $punteggioUtente;
    }else{
        $punteggioVincitore = $punteggioPc;
    }
   
    $dataPartita = date("F j, Y, g:i a");
    $_SESSION['history'][]=[
        'vincitore'=> $vincitore,
        'punteggioVincitore'=> $punteggioVincitore,
        'dataOra'=> $dataPartita
    ];

    $tentativi = count($_SESSION['history']);

    if($tentativi >= $max_tentativi) {
        header('location:risultati.php');
        
    }
    
    
    echo '<br><a href="tentativo_giocatore.php">Prossimo turno</a><br>';
}
