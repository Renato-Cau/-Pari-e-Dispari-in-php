<?php

session_start();

echo '<h4 style="color: red;">RISULTATO DEI TURNI:</h4>';


$html = '<ol>';
foreach($_SESSION['history'] as $row) {
    $vinteUtente = count($_SESSION['history']);
    $html .= '<li>Vincitore: ' . $row['vincitore'] .
             ' - Punteggio: ' . $row['punteggioVincitore'] .
             ' - Il giorno alle ore: ' . $row['dataOra'] . '</li>';
}
$html .= '</ol>';
echo $html;


echo '<br>';
echo '<br><a href="salvataggio.php">SALVA SFIDA</a>';
echo '<br>';
echo '<br><a href="index.php">NUOVA SFIDA</a>';
