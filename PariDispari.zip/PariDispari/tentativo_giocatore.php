<?php
session_start();

//echo $_SESSION['nomeGiocatore'];
//echo $_SESSION['sceltaTipo'];

echo '<h3 style="color: red;">CHE VINCA IL MIGLIORE!</h3>';
echo '<br>';
echo '<p style="font-weight: bold;">Bim,Bum,Bam..scegli un numero!<p>';
echo '<br>';
echo '<a href="giocata.php?scelta=0"><img style="max-height: 95px;" src="./mani/zero.jpg"></a>
      <a href="giocata.php?scelta=1"><img style="max-height: 95px;" src="./mani/uno.jpg"></a>
      <a href="giocata.php?scelta=2"><img style="max-height: 95px;" src="./mani/due.jpg"></a>
      <a href="giocata.php?scelta=3"><img style="max-height: 95px;" src="./mani/tre.jpg"></a>
      <a href="giocata.php?scelta=4"><img style="max-height: 95px;" src="./mani/quattro.jpg"></a>
      <a href="giocata.php?scelta=5"><img style="max-height: 95px;" src="./mani/cinque.jpg"></a>
     ';
