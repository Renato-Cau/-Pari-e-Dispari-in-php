<?php

include 'connessione.php';

session_start();
//echo '<pre>';
//print_r($_SESSION);

$currentdate = date("F j, Y, g:i a");

//preparo SQL ed eseguo
$sql = 'INSERT INTO partita (dataOra, vincitore, punteggioVincitore)
        VALUES (:dataOra, :vincitore, :punteggioVincitore)';
$sth = $db->prepare($sql);
$data = [
    ':dataOra' => $currentdate,
    ':vincitore' => $_SESSION['vincitore'],
    ':punteggioVincitore' => $_SESSION['punteggioVincitore']
];

if (! $sth->execute($data)) {
    echo '<h3 style="color: red;">ERRORE salvataggio!</h3>';
} else {
    echo '<h3 style="color: green;">Dati salvati correttamente.</h3>';
}

echo '<br><a href="inizio.php" style="text-decoration: none; color: #acaf00; font-weight: bold;">Nuova partita</a>';
